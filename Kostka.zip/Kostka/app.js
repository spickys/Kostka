var body;
var bodyVKole;
var aktivniHrac;
var koncoveBody;
var kostka;
var hraProbiha;

function init(){
    body = [0, 0];
    aktivniHrac = 0;
    bodyVKole = 0;
    koncoveBody = 100;
    hraProbiha = true;

    document.querySelector('.kostka').style.display = "none";
    document.getElementById('body-0').textContent = '0';
    document.getElementById('body-1').textContent = '0';
    document.getElementById('soucasne-0').textContent = '0';
    document.getElementById('soucasne-1').textContent = '0';
    document.querySelector('#jmeno-0').textContent = 'Hráč 1';
    document.querySelector('#jmeno-1').textContent = 'Hráč 2';
    document.querySelector('.hrac-0-panel').classList.remove('aktivni');
    document.querySelector('.hrac-1-panel').classList.remove('aktivni');
    document.querySelector('.hrac-0-panel').classList.remove('vitez');
    document.querySelector('.hrac-1-panel').classList.remove('vitez');
    document.querySelector('.hrac-0-panel').classList.add('aktivni');
};

function dalsiHrac(){
    aktivniHrac === 0 ? aktivniHrac = 1 : aktivniHrac = 0;
    bodyVKole = 0;
    document.getElementById('soucasne-0').textContent = '0';
    document.getElementById('soucasne-1').textContent = '0';
    document.querySelector('.hrac-0-panel').classList.toggle('aktivni');
    document.querySelector('.hrac-1-panel').classList.toggle('aktivni');
};

init();

document.querySelector('.tlacitko-hod').addEventListener('click', function(){
    if (hraProbiha) {
        // Nahodne cislo
        kostka = Math.floor(Math.random() * 6) + 1;
        // Zobrazit vysledek
        var kostkaDOM = document.querySelector('.kostka');
        kostkaDOM.style.display = "block";
        kostkaDOM.textContent = kostka;
        // Aktualizovat body kola pokud padla/nepadla 1
        if (kostka !== 1) {
            //Přičti body
            bodyVKole += kostka;
            document.querySelector('#soucasne-' + aktivniHrac).textContent = bodyVKole;
        }   else {
            //Přepni hráče "ternární operátor"-> if= ?; else= :
            dalsiHrac()
        }
    }
});

document.querySelector('.tlacitko-dost').addEventListener('click', function(){

    if (hraProbiha){
        // Přidat současné body k ceklovým bodům hráče
        body [aktivniHrac] += bodyVKole;
        // Aktualizovat UI
        document.querySelector('#body-' + aktivniHrac).textContent = body[aktivniHrac];
        // Zkontrolovat zda hráč již vyyhrál
        if (body[aktivniHrac] >= koncoveBody){
            document.querySelector('#jmeno-' + aktivniHrac).textContent = 'VÍTĚZ!';
            document.querySelector('.hrac-' + aktivniHrac + '-panel').classList.remove('aktivni');
            document.querySelector('.hrac-' + aktivniHrac + '-panel').classList.add('vitez');
            document.querySelector('.kostka').style.display = "none";
            hraProbiha = false
        }   else {
        // Přepnout hráče
            dalsiHrac()
        }
    }
});

document.querySelector('.tlacitko-novy').addEventListener('click', init);

alert('Pravidla hry najdeš v konzoli ⬇️F12');

console.log('✔️ Dva hráči se střídají. Házíš kostkou kolikrát chceš. Hodnota každého hodu se ti přičítá. Pokud na kostce padne 1, ztrácíš všechny body a na řadu se dostává druhý hráč. Můžeš zvolit "dost", což znamená, že všechny nahrané body se přičtou k celkovým bodům. Poté je na řadě druhý hráč. Hra končí jakmile jeden z hráčů dosáhne 100 bodů. HODNĚ ŠTĚSTÍ 🍀');

